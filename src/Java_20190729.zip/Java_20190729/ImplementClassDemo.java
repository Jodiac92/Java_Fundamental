package Java_20190729;

public class ImplementClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterA i = new ImplementClass();
		i.mA();
		i.mB();
		i.mC();
		System.out.println(InterA.PI);
	}

}
