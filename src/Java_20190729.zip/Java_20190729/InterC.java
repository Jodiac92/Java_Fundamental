package Java_20190729;

public interface InterC {
	void mC();
}
