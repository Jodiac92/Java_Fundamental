package Java_20190729;

public interface InterB {
	void mB();
}
